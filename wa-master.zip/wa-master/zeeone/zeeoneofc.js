const petik = '```'
const help = (prefix, wita, wit, ucapannya2, timuu, status, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, alfa , alfa1, thisDay, ini_tanggal, totalchat, hit_today, ini_gcchat, latensiii, tekss)=> {
	return`┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${timuu}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya2}
│◦➛Jam : ${timuu}
│◦➛Hari : ${thisDay}
└❏ Tanggal : ${ini_tanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏ MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛ Owner : ${ownername}
│◦➛Mode : ${status}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hit_today.length}
│◦➛Personal Chat : ${totalchat.length - ini_gcchat.lenght}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Group Chat : ${ini_gcchat}
│◦➛Browser : Chrome
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed :${petik} ${latensiii} 
${petik}└❏ ${tekss}${petik}


┌❑ *LIST MENU* ❑
│
${petik}├❒ Allmenu 
├❒ Convertmenu
├❒ Asupanmenu
├❒ Downloadmenu
├❒ Funmenu
├❒ Makermenu
├❒ Othermenu
├❒ Ownermenu
├❒ Storagemenu
├❒ Tagmenu
├❒ Upmenu
├❒ Set_sticker_cmd
├❒ Gacha_cecan
├❒ Telegram_sticker
└❒ Image_effect${petik}

┌❑ *ABOUT* ❑
│
${petik}├❒ Source
├❒ ThanksTo
├❒ Group_support
└❒ Ownerbot${petik}

❒ _Creator BotWea © 2K21_ ❒
`
}
const convert = (prefix) => {
	return`┌❑ *CONVERT MENU* ❑
│
${petik}├❒ ${prefix}toimg
├❒ ${prefix}tomp3
├❒ ${prefix}tomp4
├❒ ${prefix}slow
├❒ ${prefix}tupai
├❒ ${prefix}fast
├❒ ${prefix}reverse
└❒ ${prefix}tourl${petik}
`
}
const download = (prefix) => {
	return`┌❑ *DOWNLOAD MENU* ❑
│
${petik}├❒ ${prefix}ytsearch${petik} _query_
${petik}├❒ ${prefix}igstalk${petik} _username_
${petik}├❒ ${prefix}ghstalk${petik} _username_
${petik}├❒ ${prefix}play${petik} _query_
${petik}├❒ ${prefix}playmp4${petik} _query_
${petik}├❒ ${prefix}video${petik} _query_
${petik}├❒ ${prefix}ytmp3${petik} _link_
${petik}├❒ ${prefix}ytmp4${petik} _link_
${petik}├❒ ${prefix}ig${petik} _link_
${petik}├❒ ${prefix}igphoto${petik} _link_
${petik}├❒ ${prefix}igvideo${petik} _link_
${petik}├❒ ${prefix}igtv${petik} _link_
${petik}├❒ ${prefix}igreels${petik} _link_
${petik}├❒ ${prefix}twitter${petik} _link_
${petik}├❒ ${prefix}tiktokwm${petik} _link_
${petik}├❒ ${prefix}tiktoknowm${petik} _link_
${petik}├❒ ${prefix}tiktokaudio${petik} _link_
${petik}├❒ ${prefix}fb${petik} _link_
${petik}├❒ ${prefix}brainly${petik} _query_
${petik}├❒ ${prefix}image${petik} _query_
${petik}├❒ ${prefix}pinterest${petik} _query_
${petik}├❒ ${prefix}pinterest2${petik} _query_
${petik}├❒ ${prefix}playstore${petik} _query_
${petik}├❒ ${prefix}gcwa${petik} _query_
${petik}├❒ ${prefix}lirik${petik} _query_
${petik}├❒ ${prefix}komiku${petik} _query_
${petik}├❒ ${prefix}otaku${petik} _query_
${petik}└❒ ${prefix}anime${petik} _random_
`
}
const allmenu = (prefix, wita, wit, ucapannya2, timuu, status, wa_version, mcc, mnc, os_version, device_manufacturer, device_model, alfa , alfa1, thisDay, ini_tanggal, totalchat, hit_today, ini_gcchat, latensiii, tekss)  => {
	return`❏───「 *alihh* 」───❏
     
┌❏ *INDONESIA TIME*
${petik}│◦➛ WIB : ${timuu}
│◦➛ WITA : ${wita}
└❏ WIT : ${wit}${petik}
                          
┌❏ *TODAY*
${petik}│◦➛${ucapannya2}
│◦➛Jam : ${timuu}
│◦➛Hari : ${thisDay}
└❏ Tanggal : ${ini_tanggal}${petik}

┌❏ *DEVICE*
${petik}│◦➛Whatsapp : ${wa_version}
│◦➛Merk HP : ${device_manufacturer}
│◦➛Versi HP : ${device_model}
│◦➛Versi OS : ${os_version}
│◦➛RAM : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│◦➛MCC : ${mcc}
└❏ MNC : ${mnc}${petik}

┌─❑「 *BOT INFO* 」
${petik}│◦➛Mode : ${status}
│◦➛Prefix : ${prefix}
│◦➛Total Hit : ${hit_today.length}
│◦➛Personal Chat : ${totalchat.length - ini_gcchat.lenght}
│◦➛Total All Chat : ${totalchat.length}
│◦➛Group Chat : ${ini_gcchat}
│◦➛Browser : Chrome
│◦➛Server : Baileys
│◦➛Version : 3.5.2${petik}
${petik}│◦➛Speed :${petik} ${latensiii} 
${petik}└❏ ${tekss}${petik}

┌─❑「 *CONVERT MENU* 」
│
${petik}│◦ ${prefix}toimg
│◦ ${prefix}tomp3
│◦ ${prefix}tomp4
│◦ ${prefix}slow
│◦ ${prefix}tupai
│◦ ${prefix}fast
│◦ ${prefix}reverse
│◦ ${prefix}tourl${petik}
│
├❑「 *DOWNLOAD MENU* 」
│
${petik}│◦ ${prefix}ytsearch${petik} _query_
${petik}│◦ ${prefix}igstalk${petik} _username_
${petik}│◦ ${prefix}ghstalk${petik} _username_
${petik}│◦ ${prefix}play${petik} _query_
${petik}│◦ ${prefix}playmp4${petik} _query_
${petik}│◦ ${prefix}video${petik} _query_
${petik}│◦ ${prefix}ytmp3${petik} _link_
${petik}│◦ ${prefix}ytmp4${petik} _link_
${petik}│◦ ${prefix}ig${petik} _link_
${petik}│◦ ${prefix}igphoto${petik} _link_
${petik}│◦ ${prefix}igvideo${petik} _link_
${petik}│◦ ${prefix}igtv${petik} _link_
${petik}│◦ ${prefix}igreels${petik} _link_
${petik}│◦ ${prefix}twitter${petik} _link_
${petik}│◦ ${prefix}tiktokwm${petik} _link_
${petik}│◦ ${prefix}tiktoknowm${petik} _link_
${petik}│◦ ${prefix}tiktokaudio${petik} _link_
${petik}│◦ ${prefix}fb${petik} _link_
${petik}│◦ ${prefix}brainly${petik} _query_
${petik}│◦ ${prefix}image${petik} _query_
${petik}│◦ ${prefix}pinterest${petik} _query_
${petik}│◦ ${prefix}pinterest2${petik} _query_
${petik}│◦ ${prefix}playstore${petik} _query_
${petik}│◦ ${prefix}gcwa${petik} _query_
${petik}│◦ ${prefix}lirik${petik} _query_
${petik}│◦ ${prefix}komiku${petik} _query_
${petik}│◦ ${prefix}anime${petik} _random_
│
├❑「 *FUN MENU* 」
│
${petik}│◦ ${prefix}jelajah
│◦ ${prefix}adventure
│◦ ${prefix}nambang
│◦ ${prefix}nebang
│◦ ${prefix}mancing
│◦ ${prefix}lebur
│◦ ${prefix}jualikan
│◦ ${prefix}jualcoal
│◦ ${prefix}jualstone
│◦ ${prefix}jualingot
│◦ ${prefix}jualkayu
│◦ ${prefix}slot
│◦ ${prefix}inventory
│◦ ${prefix}dompet
│◦ ${prefix}suit
│◦ ${prefix}judi
│◦ ${prefix}fitnah (d)
│◦ ${prefix}absen
│◦ ${prefix}absensi
│◦ ${prefix}tebakgambar
│◦ ${prefix}caklontong
│◦ ${prefix}family100
│◦ ${prefix}tebakanime
│◦ ${prefix}suit
│◦ ${prefix}fitnahpc${petik} text|balasan
${petik}│◦ ${prefix}kontak${petik} 62xxx|text
${petik}│◦ ${prefix}tictactoe${petik} @user
${petik}│◦ ${prefix}delttt${petik}
${petik}│◦ ${prefix}voting${petik} @user|reason|time
${petik}│◦ ${prefix}delvote${petik}
${petik}│◦ ${prefix}jadibot${petik}
${petik}│◦ ${prefix}stopjadibot${petik}
${petik}│◦ ${prefix}listbot${petik}
│
├❑「 *TEXTPRO MENU* 」
│
${petik}│◦ ${prefix}halloween2${petik} text|text2
${petik}│◦ ${prefix}horror${petik} text|text2
${petik}│◦ ${prefix}game8bit${petik} text|text2
${petik}│◦ ${prefix}layered${petik} text|text2
${petik}│◦ ${prefix}glitch2${petik} text|text2
${petik}│◦ ${prefix}coolg${petik} text|text2
${petik}│◦ ${prefix}coolwg${petik} text|text2
${petik}│◦ ${prefix}realistic${petik} text|text2
${petik}│◦ ${prefix}space3d${petik} text|text2
${petik}│◦ ${prefix}gtiktok${petik} text|text2
${petik}│◦ ${prefix}stone${petik} text|text2
${petik}│◦ ${prefix}marvel${petik} text|text2
${petik}│◦ ${prefix}marvel2${petik} text|text2
${petik}│◦ ${prefix}pornhub${petik} text|text2
${petik}│◦ ${prefix}avengers${petik} text|text2
${petik}│◦ ${prefix}metalr${petik} text|text2
${petik}│◦ ${prefix}metalg${petik} text|text2
${petik}│◦ ${prefix}metalg2${petik} text|text2
${petik}│◦ ${prefix}halloween2${petik} text|text2
${petik}│◦ ${prefix}lion${petik} text|text2
${petik}│◦ ${prefix}wolf_bw${petik} text|text2
${petik}│◦ ${prefix}wolf_g${petik} text|text2
${petik}│◦ ${prefix}ninja${petik} text|text2
${petik}│◦ ${prefix}3dsteel${petik} text|text2
${petik}│◦ ${prefix}horror2${petik} text|text2
${petik}│◦ ${prefix}lava${petik} text|text2
${petik}│◦ ${prefix}bagel${petik} text|text2
${petik}│◦ ${prefix}blackpink${petik} text
${petik}│◦ ${prefix}rainbow2${petik} text
${petik}│◦ ${prefix}water_pipe${petik} text
${petik}│◦ ${prefix}halloween${petik} text
${petik}│◦ ${prefix}sketch${petik} text
${petik}│◦ ${prefix}sircuit${petik} text
${petik}│◦ ${prefix}discovery${petik} text
${petik}│◦ ${prefix}metallic2${petik} text
${petik}│◦ ${prefix}fiction${petik} text
${petik}│◦ ${prefix}demon${petik} text
${petik}│◦ ${prefix}transformer${petik} text
${petik}│◦ ${prefix}berry${petik} text
${petik}│◦ ${prefix}thunder${petik} text
${petik}│◦ ${prefix}magma${petik} text
${petik}│◦ ${prefix}3dstone${petik} text
${petik}│◦ ${prefix}neon${petik} text
${petik}│◦ ${prefix}glitch${petik} text
${petik}│◦ ${prefix}harry_potter${petik} text
${petik}│◦ ${prefix}embossed${petik} text
${petik}│◦ ${prefix}broken${petik} text
${petik}│◦ ${prefix}papercut${petik} text
${petik}│◦ ${prefix}gradient${petik} text
${petik}│◦ ${prefix}glossy${petik} text
${petik}│◦ ${prefix}watercolor${petik} text
${petik}│◦ ${prefix}multicolor${petik} text
${petik}│◦ ${prefix}neon_devil${petik} text
${petik}│◦ ${prefix}underwater${petik} text
${petik}│◦ ${prefix}bear${petik} text
${petik}│◦ ${prefix}wonderfulg${petik} text
${petik}│◦ ${prefix}christmas${petik} text
${petik}│◦ ${prefix}neon_light${petik} text
${petik}│◦ ${prefix}snow${petik} text
${petik}│◦ ${prefix}cloudsky${petik} text
${petik}│◦ ${prefix}luxury2${petik} text
${petik}│◦ ${prefix}gradient2${petik} text
${petik}│◦ ${prefix}summer${petik} text
${petik}│◦ ${prefix}writing${petik} text
${petik}│◦ ${prefix}engraved${petik} text
${petik}│◦ ${prefix}summery${petik} text
${petik}│◦ ${prefix}3dglue${petik} text
${petik}│◦ ${prefix}metaldark${petik} text
${petik}│◦ ${prefix}neonlight${petik} text
${petik}│◦ ${prefix}oscar${petik} text
${petik}│◦ ${prefix}minion${petik} text
${petik}│◦ ${prefix}holographic${petik} text
${petik}│◦ ${prefix}purple${petik} text
${petik}│◦ ${prefix}glossyb${petik} text
${petik}│◦ ${prefix}deluxe2${petik} text
${petik}│◦ ${prefix}glossyc${petik} text
${petik}│◦ ${prefix}fabric${petik} text
${petik}│◦ ${prefix}neonc${petik} text
${petik}│◦ ${prefix}newyear${petik} text
${petik}│◦ ${prefix}newyear2${petik} text
${petik}│◦ ${prefix}metals${petik} text
${petik}│◦ ${prefix}xmas${petik} text
${petik}│◦ ${prefix}blood${petik} text
${petik}│◦ ${prefix}darkg${petik} text
${petik}│◦ ${prefix}joker${petik} text
${petik}│◦ ${prefix}wicker${petik} text
${petik}│◦ ${prefix}natural${petik} text
${petik}│◦ ${prefix}firework${petik} text
${petik}│◦ ${prefix}skeleton${petik} text
${petik}│◦ ${prefix}balloon${petik} text
${petik}│◦ ${prefix}balloon2${petik} text
${petik}│◦ ${prefix}balloon3${petik} text
${petik}│◦ ${prefix}balloon4${petik} text
${petik}│◦ ${prefix}balloon5${petik} text
${petik}│◦ ${prefix}balloon6${petik} text
${petik}│◦ ${prefix}balloon7${petik} text
${petik}│◦ ${prefix}steel${petik} text
${petik}│◦ ${prefix}gloss${petik} text
${petik}│◦ ${prefix}denim${petik} text
${petik}│◦ ${prefix}decorate${petik} text
${petik}│◦ ${prefix}decorate2${petik} text
${petik}│◦ ${prefix}peridot${petik} text
${petik}│◦ ${prefix}rock${petik} text
${petik}│◦ ${prefix}glass${petik} text
${petik}│◦ ${prefix}glass2${petik} text
${petik}│◦ ${prefix}glass3${petik} text
${petik}│◦ ${prefix}glass4${petik} text
${petik}│◦ ${prefix}glass5${petik} text
${petik}│◦ ${prefix}glass6${petik} text
${petik}│◦ ${prefix}glass7${petik} text
${petik}│◦ ${prefix}glass8${petik} text
${petik}│◦ ${prefix}captain_as2${petik} text
${petik}│◦ ${prefix}robot${petik} text
${petik}│◦ ${prefix}equalizer${petik} text
${petik}│◦ ${prefix}toxic${petik} text
${petik}│◦ ${prefix}sparkling${petik} text
${petik}│◦ ${prefix}sparkling2${petik} text
${petik}│◦ ${prefix}sparkling3${petik} text
${petik}│◦ ${prefix}sparkling4${petik} text
${petik}│◦ ${prefix}sparkling5${petik} text
${petik}│◦ ${prefix}sparkling6${petik} text
${petik}│◦ ${prefix}sparkling7${petik} text
${petik}│◦ ${prefix}decorative${petik} text
${petik}│◦ ${prefix}chocolate${petik} text
${petik}│◦ ${prefix}strawberry${petik} text
${petik}│◦ ${prefix}koifish${petik} text
${petik}│◦ ${prefix}bread${petik} text
${petik}│◦ ${prefix}matrix${petik} text
${petik}│◦ ${prefix}blood2${petik} text
${petik}│◦ ${prefix}neonligth2${petik} text
${petik}│◦ ${prefix}thunder2${petik} text
${petik}│◦ ${prefix}3dbox${petik} text
${petik}│◦ ${prefix}neon2${petik} text
${petik}│◦ ${prefix}roadw${petik} text
${petik}│◦ ${prefix}bokeh${petik} text
${petik}│◦ ${prefix}gneon${petik} text
${petik}│◦ ${prefix}advanced${petik} text
${petik}│◦ ${prefix}dropwater${petik} text
${petik}│◦ ${prefix}wall${petik} text
${petik}│◦ ${prefix}chrismast${petik} text
${petik}│◦ ${prefix}honey${petik} text
${petik}│◦ ${prefix}drug${petik} text
${petik}│◦ ${prefix}marble${petik} text
${petik}│◦ ${prefix}marble2${petik} text
${petik}│◦ ${prefix}ice${petik} text
${petik}│◦ ${prefix}juice${petik} text
${petik}│◦ ${prefix}rusty${petik} text
${petik}│◦ ${prefix}abstra${petik} text
${petik}│◦ ${prefix}biscuit${petik} text
${petik}│◦ ${prefix}wood${petik} text
${petik}│◦ ${prefix}scifi${petik} text
${petik}│◦ ${prefix}metalr${petik} text
${petik}│◦ ${prefix}purpleg${petik} text
${petik}│◦ ${prefix}shiny${petik} text 
${petik}│◦ ${prefix}jewelry${petik} text
${petik}│◦ ${prefix}jewelry2${petik} text
${petik}│◦ ${prefix}jewelry3${petik} text
${petik}│◦ ${prefix}jewelry4${petik} text
${petik}│◦ ${prefix}jewelry5${petik} text
${petik}│◦ ${prefix}jewelry6${petik} text
${petik}│◦ ${prefix}jewelry7${petik} text
${petik}│◦ ${prefix}jewelry8${petik} text
${petik}│◦ ${prefix}metalh${petik} text
${petik}│◦ ${prefix}golden${petik} text
${petik}│◦ ${prefix}glitter${petik} text
${petik}│◦ ${prefix}glitter2${petik} text
${petik}│◦ ${prefix}glitter3${petik} text
${petik}│◦ ${prefix}glitter4${petik} text
${petik}│◦ ${prefix}glitter5${petik} text
${petik}│◦ ${prefix}glitter6${petik} text
${petik}│◦ ${prefix}glitter7${petik} text
${petik}│◦ ${prefix}metale${petik} text
${petik}│◦ ${prefix}carbon${petik} text
${petik}│◦ ${prefix}candy${petik} text
${petik}│◦ ${prefix}metalb${petik} text
${petik}│◦ ${prefix}gemb${petik} text
${petik}│◦ ${prefix}3dchrome${petik} text
${petik}│◦ ${prefix}metalb2${petik} text
${petik}│◦ ${prefix}metalg${petik} text
${petik}│◦ ${prefix}metalg${petik} text
│
├❑「 *PHOTOOXY MENU* 」
│
${petik}│◦ ${prefix}captain_as${petik} text|text2
${petik}│◦ ${prefix}smoke${petik} text|text2
${petik}│◦ ${prefix}tiktok2${petik} text|text2 
${petik}│◦ ${prefix}arcade${petik} text|text2
${petik}│◦ ${prefix}battlefield${petik} text|text2
${petik}│◦ ${prefix}pubg${petik} text|text2
${petik}│◦ ${prefix}shadow${petik} text
${petik}│◦ ${prefix}cname${petik} text
${petik}│◦ ${prefix}romantic${petik} text
${petik}│◦ ${prefix}burnpaper${petik} text
${petik}│◦ ${prefix}funnycup${petik} text
${petik}│◦ ${prefix}love${petik} text
${petik}│◦ ${prefix}undergrass${petik} text          
${petik}│◦ ${prefix}heart${petik} text
${petik}│◦ ${prefix}coffeecup${petik} text
${petik}│◦ ${prefix}wood${petik} text          
${petik}│◦ ${prefix}flower${petik} text         
${petik}│◦ ${prefix}wooden${petik} text 
${petik}│◦ ${prefix}3dsummer${petik} text
${petik}│◦ ${prefix}wolf_metal${petik} text
${petik}│◦ ${prefix}3dnature${petik} text
${petik}│◦ ${prefix}underwater${petik} text          
${petik}│◦ ${prefix}goldenrose${petik} text
${petik}│◦ ${prefix}vector${petik} text
${petik}│◦ ${prefix}typography${petik} text
${petik}│◦ ${prefix}typography2${petik} text 
${petik}│◦ ${prefix}underfall${petik} text  
${petik}│◦ ${prefix}smokyneon${petik} text 
${petik}│◦ ${prefix}rainbow${petik} text 
${petik}│◦ ${prefix}graffiti${petik} text
${petik}│◦ ${prefix}camouflage${petik} text
${petik}│◦ ${prefix}3dglowing${petik} text          
${petik}│◦ ${prefix}vintage${petik} text
${petik}│◦ ${prefix}honey${petik} text 
${petik}│◦ ${prefix}whitecube${petik} text
${petik}│◦ ${prefix}avatar${petik} text 
${petik}│◦ ${prefix}glowrainbow${petik} text
${petik}│◦ ${prefix}nightsky${petik} text
${petik}│◦ ${prefix}fur${petik} text
${petik}│◦ ${prefix}flaming${petik} text          
${petik}│◦ ${prefix}crisp${petik} text
${petik}│◦ ${prefix}embroidery${petik} text
${petik}│◦ ${prefix}bcake${petik} text          
${petik}│◦ ${prefix}3dligth${petik} text
${petik}│◦ ${prefix}metallic${petik} text 
${petik}│◦ ${prefix}striking${petik} text
${petik}│◦ ${prefix}watermelon${petik} text         
${petik}│◦ ${prefix}butterfly${petik} text
${petik}│◦ ${prefix}harry${petik} text
${petik}│◦ ${prefix}glowneon${petik} text
${petik}│◦ ${prefix}coffecup2${petik} text          
${petik}│◦ ${prefix}luxury${petik} text 
${petik}│◦ ${prefix}cemetery${petik} text
${petik}│◦ ${prefix}woodblock${petik} text
${petik}│◦ ${prefix}sweet${petik} text
${petik}│◦ ${prefix}simple${petik} text
${petik}│◦ ${prefix}bevel${petik} text
${petik}│◦ ${prefix}underflower${petik} text         
${petik}│◦ ${prefix}underflower2${petik} text
│
├❑「 *MAKER MENU* 」
│
${petik}│◦ ${prefix}sticker${petik}
${petik}│◦ ${prefix}smeme${petik} atas|bawah
${petik}│◦ ${prefix}ktpmaker${petik}
${petik}│◦ ${prefix}attp${petik}
${petik}│◦ ${prefix}ttp${petik}
${petik}│◦ ${prefix}ttp1${petik}
${petik}│◦ ${prefix}ttp2${petik}
${petik}│◦ ${prefix}ttp3${petik}
${petik}│◦ ${prefix}ttp4${petik}
${petik}│◦ ${prefix}swm${petik} author|packname
${petik}│◦ ${prefix}take${petik} author|packname
${petik}│◦ ${prefix}fdeface${petik}
${petik}│◦ ${prefix}amongus${petik} 
${petik}│◦ ${prefix}tweettrump${petik} text
${petik}│◦ ${prefix}cmm${petik} text
${petik}│◦ ${prefix}kanna${petik} text
${petik}│◦ ${prefix}nulis${petik} text
${petik}│◦ ${prefix}tahta${petik} text
${petik}│◦ ${prefix}ytgold${petik} text
${petik}│◦ ${prefix}ytsilver${petik}
${petik}│◦ ${prefix}emoji${petik} 👼
│
├❑ 「 *IMAGE EFFECT* 」
│
${petik}│◦ ${prefix}trigger
│◦ ${prefix}gay
│◦ ${prefix}glass
│◦ ${prefix}passed
│◦ ${prefix}jail
│◦ ${prefix}comrade
│◦ ${prefix}hijau
│◦ ${prefix}biru
│◦ ${prefix}greyscale
│◦ ${prefix}invert
│◦ ${prefix}invert_greyscale
│◦ ${prefix}red
│◦ ${prefix}blurple
│◦ ${prefix}blurple2
│◦ ${prefix}wasted
│◦ ${prefix}pelangi
│◦ ${prefix}sepia
│◦ ${prefix}wanted
│◦ ${prefix}utatoo
│◦ ${prefix}unsharpen
│◦ ${prefix}thanos
│◦ ${prefix}sniper
│◦ ${prefix}sharpen
│◦ ${prefix}scary
│◦ ${prefix}rip
│◦ ${prefix}rejected
│◦ ${prefix}redple
│◦ ${prefix}posterize
│◦ ${prefix}ps4
│◦ ${prefix}pixelize
│◦ ${prefix}missionpassed
│◦ ${prefix}moustache
│◦ ${prefix}lookwhatkarenhave
│◦ ${prefix}instagram
│◦ ${prefix}glitch
│◦ ${prefix}frame
│◦ ${prefix}fire
│◦ ${prefix}distort
│◦ ${prefix}dictator
│◦ ${prefix}deepfry
│◦ ${prefix}ddungeon
│◦ ${prefix}circle
│◦ ${prefix}challenger
│◦ ${prefix}burn
│◦ ${prefix}brazzers
│◦ ${prefix}beautiful${petik}
│
├❑「 *GROUP MENU* 」
│
${petik}│◦ ${prefix}add${petik} 62***
${petik}│◦ ${prefix}kick${petik} _@user_
${petik}│◦ ${prefix}radd${petik} _reply pesan @user_
${petik}│◦ ${prefix}rkick${petik} _reply pesan @user_
${petik}│◦ ${prefix}ping${petik}
${petik}│◦ ${prefix}nsfw${petik} _on / off_
${petik}│◦ ${prefix}antilink${petik} _on / off_
${petik}│◦ ${prefix}get${petik} _link_
${petik}│◦ ${prefix}getpp${petik} _@user_
${petik}│◦ ${prefix}getname${petik} _reply_
${petik}│◦ ${prefix}size${petik} _reply media_
${petik}│◦ ${prefix}colongsw${petik} _reply sw_
${petik}│◦ ${prefix}getbio${petik} _@user_
${petik}│◦ ${prefix}tagall
│◦ ${prefix}listonline
│◦ ${prefix}caripesan${petik} query
${petik}│◦ ${prefix}caripesan2${petik} _query_
${petik}│◦ ${prefix}searchmsg${petik} _query|total_
${petik}│◦ ${prefix}sider${petik} _reply pesan bot_
${petik}│◦ ${prefix}del${petik} _reply pesan bot_
${petik}│◦ ${prefix}q${petik} _reply pesan_
${petik}│◦ ${prefix}afk${petik} _reason_
${petik}│◦ ${prefix}getsider${petik} _reply pesan bot_
${petik}│◦ ${prefix}promoteall
│◦ ${prefix}ppcouple
│◦ ${prefix}setname
│◦ ${prefix}revoke
│◦ ${prefix}setdesk
│◦ ${prefix}spam${petik} text|jumlah
${petik}│◦ ${prefix}demoteall
│◦ ${prefix}admin
│◦ ${prefix}listpc
│◦ ${prefix}listgroup
│◦ ${prefix}hentai
│◦ ${prefix}jadian
│◦ ${prefix}trapnime
│◦ ${prefix}sewa add/del waktu
│◦ ${prefix}listsewa
│◦ ${prefix}ceksewa
│◦ ${prefix}premium add 62xxx waktu
│◦ ${prefix}cekpremium
│◦ ${prefix}listprem
│◦ ${prefix}belipremium
│◦ ${prefix}sewabot
│◦ ${prefix}verify
│◦ ${prefix}limit
│◦ ${prefix}profile
│◦ ${prefix}buylimit
│◦ ${prefix}buyglimit
│◦ ${prefix}awoo
│◦ ${prefix}megumin${petik}
│
├❑「 *OWNER MENU* 」
│
${petik}│◦ ${prefix}off
│◦ ${prefix}on
│◦ ${prefix}buggc
│◦ ${prefix}bc
│◦ ${prefix}bcimage
│◦ ${prefix}bcgif
│◦ ${prefix}bcvideo
│◦ ${prefix}bcaudio
│◦ ${prefix}bcsticker
│◦ ${prefix}virus1
│◦ ${prefix}virus2
│◦ ${prefix}virus3
│◦ ${prefix}virus4
│◦ ${prefix}ban
│◦ ${prefix}unban
│◦ ${prefix}block
│◦ ${prefix}unblock
│◦ ${prefix}status
│◦ ${prefix}clearall
│◦ ${prefix}self
│◦ ${prefix}public
│◦ ${prefix}join
│◦ ${prefix}leave
│◦ ${prefix}clearall
│◦ ${prefix}readall
│◦ ${prefix}unreadall
│◦ ${prefix}archive
│◦ ${prefix}unarchive
│◦ ${prefix}pin
│◦ ${prefix}delthischat
│◦ ${prefix}unpin${petik}
${petik}│◦ ${prefix}autoread${petik} <query> on / off
${petik}│◦ ${prefix}antibug${petik} on / off
${petik}│◦ ${prefix}antidelete${petik} on / off
${petik}│◦ ${prefix}anticall${petik} on / off
${petik}│◦ ${prefix}autoketik${petik} on / off
${petik}│◦ ${prefix}autovn${petik} on / off
${petik}│◦ ${prefix}antihidetag${petik} on / off
${petik}│◦ ${prefix}autobio${petik} on / off
${petik}│◦ ${prefix}register${petik} on / off
${petik}│◦ ${prefix}autorespon${petik} on / off
${petik}│◦ ${prefix}setthumb
│◦ ${prefix}settarget
│◦ ${prefix}setfakeimg
│◦ ${prefix}setreply${petik}
${petik}│◦ ${prefix}term${petik} _code_
${petik}│◦ x or >${petik} _code_
${petik}│◦ $ ${petik} _termux code_
${petik}│◦ => ${petik} _eval async_
│
├❑「 *SET STC CMD* 」
│
${petik}│◦ ${prefix}set_stc_menu${petik} _<query>_
${petik}│◦ ${prefix}set_stc_ping${petik} _<query>_
${petik}│◦ ${prefix}set_stc_gclose${petik} _<query>_
${petik}│◦ ${prefix}set_stc_gopen${petik} _<query>_
${petik}│◦ ${prefix}set_stc_itos${petik} _<query>_
${petik}│◦ ${prefix}set_stc_toimg${petik} _<query>_
${petik}│◦ ${prefix}set_stc_self${petik} _<query>_
${petik}│◦ ${prefix}set_stc_public${petik} _<query>_
│
├❑「 *STORAGE  MENU* 」
│
${petik}│◦ ${prefix}addstik 
│◦ ${prefix}addimg 
│◦ ${prefix}addvid 
│◦ ${prefix}addvn   
│◦ ${prefix}liststick
│◦ ${prefix}listimg
│◦ ${prefix}listvid
│◦ ${prefix}listvn
│◦ ${prefix}addrespon
│◦ ${prefix}delrespon
│◦ ${prefix}listrespon${petik}
│
├❑「 *TAG  MENU* 」
│
${petik}│◦ ${prefix}hidetag
│◦ ${prefix}kontag
│◦ ${prefix}sticktag
│◦ ${prefix}totag${petik}
│
├❑「 *UP ESWE* 」
│
${petik}│◦ ${prefix}upswteks
│◦ ${prefix}upswimage
│◦ ${prefix}upswvideo${petik}
│
├❑「 *NSFW & SFW* 」
│
${petik}│◦ ${prefix}ahegao
│◦ ${prefix}ass
│◦ ${prefix}bdsm
│◦ ${prefix}blowjob
│◦ ${prefix}blowjob2
│◦ ${prefix}cuckold
│◦ ${prefix}cum
│◦ ${prefix}ero
│◦ ${prefix}femdom
│◦ ${prefix}foot
│◦ ${prefix}gangbang
│◦ ${prefix}glasses
│◦ ${prefix}jahy
│◦ ${prefix}manga
│◦ ${prefix}masturbation
│◦ ${prefix}neko
│◦ ${prefix}orgy
│◦ ${prefix}panties
│◦ ${prefix}pussy
│◦ ${prefix}tentacles
│◦ ${prefix}thighs
│◦ ${prefix}yuri
│◦ ${prefix}feet
│◦ ${prefix}lewdkemo
│◦ ${prefix}woof
│◦ ${prefix}gasm
│◦ ${prefix}solo
│◦ ${prefix}8ball
│◦ ${prefix}goose
│◦ ${prefix}avatar
│◦ ${prefix}hololewd
│◦ ${prefix}gecg
│◦ ${prefix}holo
│◦ ${prefix}fox_girl
│◦ ${prefix}tits
│◦ ${prefix}eroyuri
│◦ ${prefix}holoyero
│◦ ${prefix}lizard
│◦ ${prefix}keta
│◦ ${prefix}eron
│◦ ${prefix}erok
│◦ ${prefix}kemonomimi
│◦ ${prefix}cum_jpg
│◦ ${prefix}nsfw_avatar
│◦ ${prefix}erofeet
│◦ ${prefix}meow
│◦ ${prefix}wallpaper
│◦ ${prefix}waifu
│◦ ${prefix}trap
│◦ ${prefix}lewd
│◦ ${prefix}pussy_jpg
│◦ ${prefix}futanari
│◦ ${prefix}lewdk
│◦ ${prefix}solog
│◦ ${prefix}smug
│◦ ${prefix}cum
│◦ ${prefix}slap
│◦ ${prefix}les
│◦ ${prefix}erokemo
│◦ ${prefix}bj
│◦ ${prefix}pwankg
│◦ ${prefix}pat
│◦ ${prefix}poke
│◦ ${prefix}feed
│◦ ${prefix}nsfw_neko_gif
│◦ ${prefix}pussy
│◦ ${prefix}feetg
│◦ ${prefix}baka
│◦ ${prefix}hug
│◦ ${prefix}kiss
│◦ ${prefix}tickle
│◦ ${prefix}spank
│◦ ${prefix}kuni
│◦ ${prefix}classic
│◦ ${prefix}boobs
│◦ ${prefix}anal
│◦ ${prefix}ngif
│◦ ${prefix}cuddle
│◦ ${prefix}zettai${petik}
│
├❑ 「 *STC  MENU* 」
│
${petik}│◦ ${prefix}awoawo
│◦ ${prefix}benedict
│◦ ${prefix}chat
│◦ ${prefix}dbfly
│◦ ${prefix}dino_kuning
│◦ ${prefix}doge
│◦ ${prefix}gojosatoru
│◦ ${prefix}hope_boy
│◦ ${prefix}jisoo
│◦ ${prefix}kr_robot
│◦ ${prefix}kucing
│◦ ${prefix}lonte
│◦ ${prefix}manusia_lidi
│◦ ${prefix}menjamet
│◦ ${prefix}meow
│◦ ${prefix}nicholas
│◦ ${prefix}patrick
│◦ ${prefix}popoci
│◦ ${prefix}sponsbob
│◦ ${prefix}kawan_sponsbob
│◦ ${prefix}tyni${petik}
│
├❑「 *CECAN  MENU* 」 
│
${petik}│◦ ${prefix}china
│◦ ${prefix}indonesia
│◦ ${prefix}malaysia
│◦ ${prefix}thailand
│◦ ${prefix}korea
│◦ ${prefix}japan
│◦ ${prefix}vietnam
│◦ ${prefix}jenni
│◦ ${prefix}jiso
│◦ ${prefix}lisa
│◦ ${prefix}rose${petik}
│
├❑「 *QUOTES  MENU* 」 
│
│◦ ${petik}${prefix}katailham${petik}  
│◦ ${petik}${prefix}dare${petik}   
│◦ ${petik}${prefix}truth${petik}  
│◦ ${petik}${prefix}katabijak_lucu${petik}   
│◦ ${petik}${prefix}katacaklontong${petik}  
│◦ ${petik}${prefix}katadilan${petik}  
│
├❑「 *COGAN  MENU* 」 
│
│◦ ${petik}${prefix}baekhyung${petik}  
│◦ ${petik}${prefix}dohkyungsoo${petik}  
│◦ ${petik}${prefix}huangzitao${petik}  
│◦ ${petik}${prefix}jhope${petik}  
│◦ ${petik}${prefix}jimin${petik} 
│◦ ${petik}${prefix}jungkook${petik} 
│◦ ${petik}${prefix}kimjondae${petik}  
│◦ ${petik}${prefix}kimjong${petik}  
│◦ ${petik}${prefix}kimjunmyeon${petik}  
│◦ ${petik}${prefix}kimminseok${petik} 
│◦ ${petik}${prefix}kimnanjoon${petik}  
│◦ ${petik}${prefix}kimseok${petik}  
│◦ ${petik}${prefix}kimtaehyung${petik}  
│◦ ${petik}${prefix}luhan${petik}  
│◦ ${petik}${prefix}ohsehun${petik} 
│◦ ${petik}${prefix}parkchanyeol${petik} 
│◦ ${petik}${prefix}suga${petik}  
│◦ ${petik}${prefix}wuyifan${petik}
│
├❑「 *ASUPAN  MENU* 」
│
${petik}│◦ ${prefix}rikagusriani 
│◦ ${prefix}ukhty 
│◦ ${prefix}santuy 
│◦ ${prefix}geayubi   
│◦ ${prefix}bocil
│◦ ${prefix}asupan
│◦ ${prefix}chika 
│◦ ${prefix}delvira 
│◦ ${prefix}ayu   
│◦ ${prefix}bunga
│◦ ${prefix}aura
│◦ ${prefix}nisa 
│◦ ${prefix}ziva 
│◦ ${prefix}yana   
│◦ ${prefix}viona
│◦ ${prefix}syania
│◦ ${prefix}riri   
│◦ ${prefix}syifa
│◦ ${prefix}mama_gina
│◦ ${prefix}alcakenya 
│◦ ${prefix}mangayutri${petik}
│
├❑「 *ANIME  MENU* 」
│
│◦ ${petik}${prefix}anna${petik}
│◦ ${petik}${prefix}asuna_yuki${petik} 
│◦ ${petik}${prefix}ayuzawa${petik} 
│◦ ${petik}${prefix}chitoge${petik} 
│◦ ${petik}${prefix}emilia${petik}
│◦ ${petik}${prefix}erza${petik} 
│◦ ${petik}${prefix}hinata${petik} 
│◦ ${petik}${prefix}inori${petik} 
│◦ ${petik}${prefix}kaga_kouko${petik} 
│◦ ${petik}${prefix}kaori_miyazono${petik} 
│◦ ${petik}${prefix}kotori_minami${petik}
│◦ ${petik}${prefix}mikasa${petik} 
│◦ ${petik}${prefix}mio_akiyama${petik} 
│◦ ${petik}${prefix}mizore_sirayuki${petik} 
│◦ ${petik}${prefix}nakiri_alice${petik} 
│◦ ${petik}${prefix}naruto${petik} 
│◦ ${petik}${prefix}riyas_gremori${petik}
│◦ ${petik}${prefix}sakura${petik} 
│◦ ${petik}${prefix}sasuke${petik} 
│◦ ${petik}${prefix}sento_isuzu${petik} 
│◦ ${petik}${prefix}shana${petik} 
│◦ ${petik}${prefix}shiina${petik} 
│◦ ${petik}${prefix}shinka${petik}
│◦ ${petik}${prefix}winry${petik}
│◦ ${petik}${prefix}yukino${petik} 
│◦ ${petik}${prefix}yuzuki${petik} 
│◦ ${petik}${prefix}akame${petik}
│◦ ${petik}${prefix}mikosiba${petik}
│
└─❑「 MENU BOT 」

❏───「 *alihh* 」───❏
`
}

const fun = (prefix) => {
	return`┌❑  *FUN & GAME MENU* ❑
│
${petik}├❒ ${prefix}jelajah
├❒ ${prefix}adventure
├❒ ${prefix}nambang
├❒ ${prefix}nebang
├❒ ${prefix}mancing
├❒ ${prefix}lebur
├❒ ${prefix}jualikan
├❒ ${prefix}jualcoal
├❒ ${prefix}jualstone
├❒ ${prefix}jualingot
├❒ ${prefix}jualkayu
├❒ ${prefix}slot
├❒ ${prefix}inventory
├❒ ${prefix}dompet
├❒ ${prefix}suit
├❒ ${prefix}judi
├❒ ${prefix}fitnah
├❒ ${prefix}absen
├❒ ${prefix}absensi
├❒ ${prefix}tebakgambar
├❒ ${prefix}caklontong
├❒ ${prefix}family100
├❒ ${prefix}tebakanime
├❒ ${prefix}fitnahpc${petik} text|balasan
${petik}├❒ ${prefix}kontak${petik} 62xxx|text
${petik}├❒ ${prefix}tictactoe${petik} @user
${petik}├❒ ${prefix}delttt${petik}
${petik}├❒ ${prefix}voting${petik}
${petik}├❒ ${prefix}delvote${petik}
${petik}├❒ ${prefix}jadibot${petik}
${petik}├❒ ${prefix}stopjadibot${petik}
${petik}└❒ ${prefix}listbot${petik}
`
}

const maker = (prefix) => {
	return`┌❑  *MAKER MENU* ❑
│
${petik}├❒ ${prefix}sticker${petik}
${petik}├❒ ${prefix}smeme${petik}
${petik}├❒ ${prefix}ktpmaker${petik}
${petik}├❒ ${prefix}attp${petik}
${petik}├❒ ${prefix}ttp${petik}
${petik}├❒ ${prefix}ttp1${petik}
${petik}├❒ ${prefix}ttp2${petik}
${petik}├❒ ${prefix}ttp3${petik}
${petik}├❒ ${prefix}ttp4${petik}
${petik}├❒ ${prefix}swm${petik} author|packname
${petik}├❒ ${prefix}take${petik} author|packname
${petik}│❒ ${prefix}fdeface${petik}
${petik}│❒ ${prefix}amongus${petik} 
${petik}│❒ ${prefix}tweettrump${petik} text
${petik}│❒ ${prefix}cmm${petik} text
${petik}│❒ ${prefix}kanna${petik} text
${petik}│❒ ${prefix}nulis${petik} text
${petik}│❒ ${prefix}tahta${petik} text
${petik}│❒ ${prefix}ytgold${petik} text
${petik}│❒ ${prefix}ytsilver${petik}
${petik}└❒ ${prefix}emoji${petik} 👼
`
}

const textpro = (prefix) => {
	return`┌❑  *TEXTPRO MENU* ❑
│
${petik}├❒ ${prefix}halloween2${petik} text|text2
${petik}├❒ ${prefix}horror${petik} text|text2
${petik}├❒ ${prefix}game8bit${petik} text|text2
${petik}├❒ ${prefix}layered${petik} text|text2
${petik}├❒ ${prefix}glitch2${petik} text|text2
${petik}├❒ ${prefix}coolg${petik} text|text2
${petik}├❒ ${prefix}coolwg${petik} text|text2
${petik}├❒ ${prefix}realistic${petik} text|text2
${petik}├❒ ${prefix}space3d${petik} text|text2
${petik}├❒ ${prefix}gtiktok${petik} text|text2
${petik}├❒ ${prefix}stone${petik} text|text2
${petik}├❒ ${prefix}marvel${petik} text|text2
${petik}├❒ ${prefix}marvel2${petik} text|text2
${petik}├❒ ${prefix}pornhub${petik} text|text2
${petik}├❒ ${prefix}avengers${petik} text|text2
${petik}├❒ ${prefix}metalr${petik} text|text2
${petik}├❒ ${prefix}metalg${petik} text|text2
${petik}├❒ ${prefix}metalg2${petik} text|text2
${petik}├❒ ${prefix}halloween2${petik} text|text2
${petik}├❒ ${prefix}lion${petik} text|text2
${petik}├❒ ${prefix}wolf_bw${petik} text|text2
${petik}├❒ ${prefix}wolf_g${petik} text|text2
${petik}├❒ ${prefix}ninja${petik} text|text2
${petik}├❒ ${prefix}3dsteel${petik} text|text2
${petik}├❒ ${prefix}horror2${petik} text|text2
${petik}├❒ ${prefix}lava${petik} text|text2
${petik}├❒ ${prefix}bagel${petik} text|text2
${petik}├❒ ${prefix}blackpink${petik} text
${petik}├❒ ${prefix}rainbow2${petik} text
${petik}├❒ ${prefix}water_pipe${petik} text
${petik}├❒ ${prefix}halloween${petik} text
${petik}├❒ ${prefix}sketch${petik} text
${petik}├❒ ${prefix}sircuit${petik} text
${petik}├❒ ${prefix}discovery${petik} text
${petik}├❒ ${prefix}metallic2${petik} text
${petik}├❒ ${prefix}fiction${petik} text
${petik}├❒ ${prefix}demon${petik} text
${petik}├❒ ${prefix}transformer${petik} text
${petik}├❒ ${prefix}berry${petik} text
${petik}├❒ ${prefix}thunder${petik} text
${petik}├❒ ${prefix}magma${petik} text
${petik}├❒ ${prefix}3dstone${petik} text
${petik}├❒ ${prefix}neon${petik} text
${petik}├❒ ${prefix}glitch${petik} text
${petik}├❒ ${prefix}harry_potter${petik} text
${petik}├❒ ${prefix}embossed${petik} text
${petik}├❒ ${prefix}broken${petik} text
${petik}├❒ ${prefix}papercut${petik} text
${petik}├❒ ${prefix}gradient${petik} text
${petik}├❒ ${prefix}glossy${petik} text
${petik}├❒ ${prefix}watercolor${petik} text
${petik}├❒ ${prefix}multicolor${petik} text
${petik}├❒ ${prefix}neon_devil${petik} text
${petik}├❒ ${prefix}underwater${petik} text
${petik}├❒ ${prefix}bear${petik} text
${petik}├❒ ${prefix}wonderfulg${petik} text
${petik}├❒ ${prefix}christmas${petik} text
${petik}├❒ ${prefix}neon_light${petik} text
${petik}├❒ ${prefix}snow${petik} text
${petik}├❒ ${prefix}cloudsky${petik} text
${petik}├❒ ${prefix}luxury2${petik} text
${petik}├❒ ${prefix}gradient2${petik} text
${petik}├❒ ${prefix}summer${petik} text
${petik}├❒ ${prefix}writing${petik} text
${petik}├❒ ${prefix}engraved${petik} text
${petik}├❒ ${prefix}summery${petik} text
${petik}├❒ ${prefix}3dglue${petik} text
${petik}├❒ ${prefix}metaldark${petik} text
${petik}├❒ ${prefix}neonlight${petik} text
${petik}├❒ ${prefix}oscar${petik} text
${petik}├❒ ${prefix}minion${petik} text
${petik}├❒ ${prefix}holographic${petik} text
${petik}├❒ ${prefix}purple${petik} text
${petik}├❒ ${prefix}glossyb${petik} text
${petik}├❒ ${prefix}deluxe2${petik} text
${petik}├❒ ${prefix}glossyc${petik} text
${petik}├❒ ${prefix}fabric${petik} text
${petik}├❒ ${prefix}neonc${petik} text
${petik}├❒ ${prefix}newyear${petik} text
${petik}├❒ ${prefix}newyear2${petik} text
${petik}├❒ ${prefix}metals${petik} text
${petik}├❒ ${prefix}xmas${petik} text
${petik}├❒ ${prefix}blood${petik} text
${petik}├❒ ${prefix}darkg${petik} text
${petik}├❒ ${prefix}joker${petik} text
${petik}├❒ ${prefix}wicker${petik} text
${petik}├❒ ${prefix}natural${petik} text
${petik}├❒ ${prefix}firework${petik} text
${petik}├❒ ${prefix}skeleton${petik} text
${petik}├❒ ${prefix}balloon${petik} text
${petik}├❒ ${prefix}balloon2${petik} text
${petik}├❒ ${prefix}balloon3${petik} text
${petik}├❒ ${prefix}balloon4${petik} text
${petik}├❒ ${prefix}balloon5${petik} text
${petik}├❒ ${prefix}balloon6${petik} text
${petik}├❒ ${prefix}balloon7${petik} text
${petik}├❒ ${prefix}steel${petik} text
${petik}├❒ ${prefix}gloss${petik} text
${petik}├❒ ${prefix}denim${petik} text
${petik}├❒ ${prefix}decorate${petik} text
${petik}├❒ ${prefix}decorate2${petik} text
${petik}├❒ ${prefix}peridot${petik} text
${petik}├❒ ${prefix}rock${petik} text
${petik}├❒ ${prefix}glass${petik} text
${petik}├❒ ${prefix}glass2${petik} text
${petik}├❒ ${prefix}glass3${petik} text
${petik}├❒ ${prefix}glass4${petik} text
${petik}├❒ ${prefix}glass5${petik} text
${petik}├❒ ${prefix}glass6${petik} text
${petik}├❒ ${prefix}glass7${petik} text
${petik}├❒ ${prefix}glass8${petik} text
${petik}├❒ ${prefix}captain_as2${petik} text
${petik}├❒ ${prefix}robot${petik} text
${petik}├❒ ${prefix}equalizer${petik} text
${petik}├❒ ${prefix}toxic${petik} text
${petik}├❒ ${prefix}sparkling${petik} text
${petik}├❒ ${prefix}sparkling2${petik} text
${petik}├❒ ${prefix}sparkling3${petik} text
${petik}├❒ ${prefix}sparkling4${petik} text
${petik}├❒ ${prefix}sparkling5${petik} text
${petik}├❒ ${prefix}sparkling6${petik} text
${petik}├❒ ${prefix}sparkling7${petik} text
${petik}├❒ ${prefix}decorative${petik} text
${petik}├❒ ${prefix}chocolate${petik} text
${petik}├❒ ${prefix}strawberry${petik} text
${petik}├❒ ${prefix}koifish${petik} text
${petik}├❒ ${prefix}bread${petik} text
${petik}├❒ ${prefix}matrix${petik} text
${petik}├❒ ${prefix}blood2${petik} text
${petik}├❒ ${prefix}neonligth2${petik} text
${petik}├❒ ${prefix}thunder2${petik} text
${petik}├❒ ${prefix}3dbox${petik} text
${petik}├❒ ${prefix}neon2${petik} text
${petik}├❒ ${prefix}roadw${petik} text
${petik}├❒ ${prefix}bokeh${petik} text
${petik}├❒ ${prefix}gneon${petik} text
${petik}├❒ ${prefix}advanced${petik} text
${petik}├❒ ${prefix}dropwater${petik} text
${petik}├❒ ${prefix}wall${petik} text
${petik}├❒ ${prefix}chrismast${petik} text
${petik}├❒ ${prefix}honey${petik} text
${petik}├❒ ${prefix}drug${petik} text
${petik}├❒ ${prefix}marble${petik} text
${petik}├❒ ${prefix}marble2${petik} text
${petik}├❒ ${prefix}ice${petik} text
${petik}├❒ ${prefix}juice${petik} text
${petik}├❒ ${prefix}rusty${petik} text
${petik}├❒ ${prefix}abstra${petik} text
${petik}├❒ ${prefix}biscuit${petik} text
${petik}├❒ ${prefix}wood${petik} text
${petik}├❒ ${prefix}scifi${petik} text
${petik}├❒ ${prefix}metalr${petik} text
${petik}├❒ ${prefix}purpleg${petik} text
${petik}├❒ ${prefix}shiny${petik} text 
${petik}├❒ ${prefix}jewelry${petik} text
${petik}├❒ ${prefix}jewelry2${petik} text
${petik}├❒ ${prefix}jewelry3${petik} text
${petik}├❒ ${prefix}jewelry4${petik} text
${petik}├❒ ${prefix}jewelry5${petik} text
${petik}├❒ ${prefix}jewelry6${petik} text
${petik}├❒ ${prefix}jewelry7${petik} text
${petik}├❒ ${prefix}jewelry8${petik} text
${petik}├❒ ${prefix}metalh${petik} text
${petik}├❒ ${prefix}golden${petik} text
${petik}├❒ ${prefix}glitter${petik} text
${petik}├❒ ${prefix}glitter2${petik} text
${petik}├❒ ${prefix}glitter3${petik} text
${petik}├❒ ${prefix}glitter4${petik} text
${petik}├❒ ${prefix}glitter5${petik} text
${petik}├❒ ${prefix}glitter6${petik} text
${petik}├❒ ${prefix}glitter7${petik} text
${petik}├❒ ${prefix}metale${petik} text
${petik}├❒ ${prefix}carbon${petik} text
${petik}├❒ ${prefix}candy${petik} text
${petik}├❒ ${prefix}metalb${petik} text
${petik}├❒ ${prefix}gemb${petik} text
${petik}├❒ ${prefix}3dchrome${petik} text
${petik}├❒ ${prefix}metalb2${petik} text
${petik}├❒ ${prefix}metalg${petik} text
${petik}└❒ ${prefix}metalg${petik} text
`
}

const photooxy = (prefix) => {
	return`┌❑  *PHOTOOXY MENU* ❑
│
${petik}├❒ ${prefix}captain_as${petik} text|text2
${petik}├❒ ${prefix}smoke${petik} text|text2
${petik}├❒ ${prefix}tiktok2${petik} text|text2 
${petik}├❒ ${prefix}arcade${petik} text|text2
${petik}├❒ ${prefix}battlefield${petik} text|text2
${petik}├❒ ${prefix}pubg${petik} text|text2
${petik}├❒ ${prefix}shadow${petik} text
${petik}├❒ ${prefix}cname${petik} text
${petik}├❒ ${prefix}romantic${petik} text
${petik}├❒ ${prefix}burnpaper${petik} text
${petik}├❒ ${prefix}funnycup${petik} text
${petik}├❒ ${prefix}love${petik} text
${petik}├❒ ${prefix}undergrass${petik} text          
${petik}├❒ ${prefix}heart${petik} text
${petik}├❒ ${prefix}coffeecup${petik} text
${petik}├❒ ${prefix}wood${petik} text          
${petik}├❒ ${prefix}flower${petik} text         
${petik}├❒ ${prefix}wooden${petik} text 
${petik}├❒ ${prefix}3dsummer${petik} text
${petik}├❒ ${prefix}wolf_metal${petik} text
${petik}├❒ ${prefix}3dnature${petik} text
${petik}├❒ ${prefix}underwater${petik} text          
${petik}├❒ ${prefix}goldenrose${petik} text
${petik}├❒ ${prefix}vector${petik} text
${petik}├❒ ${prefix}typography${petik} text
${petik}├❒ ${prefix}typography2${petik} text 
${petik}├❒ ${prefix}underfall${petik} text  
${petik}├❒ ${prefix}smokyneon${petik} text 
${petik}├❒ ${prefix}rainbow${petik} text 
${petik}├❒ ${prefix}graffiti${petik} text
${petik}├❒ ${prefix}camouflage${petik} text
${petik}├❒ ${prefix}3dglowing${petik} text          
${petik}├❒ ${prefix}vintage${petik} text
${petik}├❒ ${prefix}honey${petik} text 
${petik}├❒ ${prefix}whitecube${petik} text
${petik}├❒ ${prefix}avatar${petik} text 
${petik}├❒ ${prefix}glowrainbow${petik} text
${petik}├❒ ${prefix}nightsky${petik} text
${petik}├❒ ${prefix}fur${petik} text
${petik}├❒ ${prefix}flaming${petik} text          
${petik}├❒ ${prefix}crisp${petik} text
${petik}├❒ ${prefix}embroidery${petik} text
${petik}├❒ ${prefix}bcake${petik} text          
${petik}├❒ ${prefix}3dligth${petik} text
${petik}├❒ ${prefix}metallic${petik} text 
${petik}├❒ ${prefix}striking${petik} text
${petik}├❒ ${prefix}watermelon${petik} text         
${petik}├❒ ${prefix}butterfly${petik} text
${petik}├❒ ${prefix}harry${petik} text
${petik}├❒ ${prefix}glowneon${petik} text
${petik}├❒ ${prefix}coffecup2${petik} text          
${petik}├❒ ${prefix}luxury${petik} text 
${petik}├❒ ${prefix}cemetery${petik} text
${petik}├❒ ${prefix}woodblock${petik} text
${petik}├❒ ${prefix}sweet${petik} text
${petik}├❒ ${prefix}simple${petik} text
${petik}├❒ ${prefix}bevel${petik} text
${petik}├❒ ${prefix}underflower${petik} text         
${petik}└❒ ${prefix}underflower2${petik} text
`
}

const other = (prefix) => {
	return`┌❑  *GROUP MENU* ❑
│
${petik}├❒ ${prefix}add${petik} 62xxx
${petik}├❒ ${prefix}kick${petik} 62xxx
${petik}├❒ ${prefix}ping${petik}
${petik}├❒ ${prefix}antilink${petik} _on / off_
${petik}├❒ ${prefix}get${petik} _link_
${petik}├❒ ${prefix}getpp${petik} _@user_
${petik}├❒ ${prefix}getbio${petik} _@user_
${petik}├❒ ${prefix}getname${petik} _reply_
${petik}├❒ ${prefix}size${petik} _reply media_
${petik}├❒ ${prefix}colongsw${petik} _reply sw_
${petik}├❒ ${prefix}tagall
├❒ ${prefix}listonline
├❒ ${prefix}caripesan${petik} query
${petik}├❒ ${prefix}caripesan2${petik} _query_
${petik}├❒ ${prefix}searchmsg${petik} _query|total_
${petik}├❒ ${prefix}sider${petik} _reply pesan bot_
${petik}├❒ ${prefix}del${petik} _reply pesan bot_
${petik}├❒ ${prefix}q${petik} _reply pesan_
${petik}├❒ ${prefix}afk${petik} _reason_
${petik}├❒ ${prefix}getsider${petik} _reply pesan bot_
${petik}├❒ ${prefix}tagall
├❒ ${prefix}revoke
├❒ ${prefix}setname
├❒ ${prefix}ppcouple
├❒ ${prefix}promoteall
├❒ ${prefix}demoteall
├❒ ${prefix}admin
├❒ ${prefix}hentai
├❒ ${prefix}jadian
├❒ ${prefix}trapnime
├❒ ${prefix}sewa add/del waktu
├❒ ${prefix}listsewa
├❒ ${prefix}ceksewa
├❒ ${prefix}premium add @user waktu
├❒ ${prefix}cekpremium
├❒ ${prefix}listprem
├❒ ${prefix}belipremium
├❒ ${prefix}sewabot
├❒ ${prefix}verify
├❒ ${prefix}limit
├❒ ${prefix}profile
├❒ ${prefix}buylimit
├❒ ${prefix}buyglimit
├❒ ${prefix}blowjob
├❒ ${prefix}awoo
└❒ ${prefix}megumin${petik}
`
}

const ownermenu = (prefix) => {
	return`┌❑  *OWNER MENU* ❑
│
${petik}├❒ ${prefix}off
├❒ ${prefix}on
├❒ ${prefix}buggc
├❒ ${prefix}bc
├❒ ${prefix}bcimage
├❒ ${prefix}bcgif
├❒ ${prefix}bcvideo
├❒ ${prefix}bcaudio
├❒ ${prefix}bcsticker
├❒ ${prefix}virus1
├❒ ${prefix}virus2
├❒ ${prefix}virus3
├❒ ${prefix}virus4
├❒ ${prefix}ban
├❒ ${prefix}unban
├❒ ${prefix}block
├❒ ${prefix}unblock
├❒ ${prefix}status
├❒ ${prefix}clearall
├❒ ${prefix}self
├❒ ${prefix}public
├❒ ${prefix}join 
├❒ ${prefix}leave
├❒ ${prefix}readall
├❒ ${prefix}unreadall
├❒ ${prefix}archive
├❒ ${prefix}unarchive
├❒ ${prefix}pin
├❒ ${prefix}delthischat
├❒ ${prefix}unpin
├❒ ${prefix}autoread <query> on / off
├❒ ${prefix}antibug on / off
├❒ ${prefix}antidelete on / off
├❒ ${prefix}anticall on / off
├❒ ${prefix}autoketik on / off
├❒ ${prefix}autobio on / off
├❒ ${prefix}antihidetag on / off
├❒ ${prefix}autovn on / off
├❒ ${prefix}register on / off
├❒ ${prefix}autorespon on / off
├❒ ${prefix}setthumb
├❒ ${prefix}settarget
├❒ ${prefix}setfakeimg
├❒ ${prefix}setreply${petik}
${petik}├❒ ${prefix}term${petik} _code_
${petik}├❒ $ ${petik} _termux code_
${petik}├❒ => ${petik} _eval async_
${petik}└❒ x or >${petik} _code_
`
}

const setStcCmd = (prefix) => {
	return`┌❑  *SET STC CMD* ❑
│
${petik}├❒ ${prefix}set_stc_menu
├❒ ${prefix}set_stc_ping
├❒ ${prefix}set_stc_gclose
├❒ ${prefix}set_stc_gopen
├❒ ${prefix}set_stc_itos
├❒ ${prefix}set_stc_toimg
├❒ ${prefix}set_stc_self
└❒ ${prefix}set_stc_public${petik}

Cara penggunaan :
> ${prefix}set_stc_menu _fileLenght sticker_

Example :
> ${prefix}set_stc_menu 7446
`
}

const storage = (prefix) => {
	return`┌❑  *STORAGE MENU* ❑
│
${petik}├❒ ${prefix}addstik 
├❒ ${prefix}addimg 
├❒ ${prefix}addvid 
├❒ ${prefix}addvn   
├❒ ${prefix}liststick
├❒ ${prefix}listimg
├❒ ${prefix}listvid
├❒ ${prefix}listvn
├❒ ${prefix}addrespon
├❒ ${prefix}delrespon
└❒ ${prefix}listrespon${petik}
`
}
const cecanmenu = (prefix) => {
	return`┌❑  *GACHA CECAN* ❑
│
${petik}├❒ ${prefix}china
├❒ ${prefix}indonesia
├❒ ${prefix}malaysia
├❒ ${prefix}thailand
├❒ ${prefix}korea
├❒ ${prefix}japan
├❒ ${prefix}vietnam
├❒ ${prefix}jenni
├❒ ${prefix}jiso
├❒ ${prefix}lisa
└❒ ${prefix}rose${petik}
`
}

const tag = (prefix) => {
	return`┌❑  *TAG MENU* ❑
│
${petik}├❒ ${prefix}hidetag
├❒ ${prefix}kontag
├❒ ${prefix}sticktag
└❒ ${prefix}totag${petik}
`
}

const upmenu = (prefix) => {
	return`┌❑  *UP ESWE* ❑
│
${petik}├❒ ${prefix}upswteks
├❒ ${prefix}upswimage
└❒ ${prefix}upswvideo${petik}
`
}
const nsfw = (prefix) => {
	return`┌❑  *NSFW & SFW* ❑
│
${petik}├❒ ${prefix}ahegao
├❒ ${prefix}ass
├❒ ${prefix}bdsm
├❒ ${prefix}blowjob
├❒ ${prefix}blowjob2
├❒ ${prefix}cuckold
├❒ ${prefix}cum
├❒ ${prefix}ero
├❒ ${prefix}femdom
├❒ ${prefix}foot
├❒ ${prefix}gangbang
├❒ ${prefix}glasses
├❒ ${prefix}jahy
├❒ ${prefix}manga
├❒ ${prefix}masturbation
├❒ ${prefix}neko
├❒ ${prefix}orgy
├❒ ${prefix}panties
├❒ ${prefix}pussy
├❒ ${prefix}tentacles
├❒ ${prefix}thighs
├❒ ${prefix}yuri
├❒ ${prefix}feet
├❒ ${prefix}lewdkemo
├❒ ${prefix}woof
├❒ ${prefix}gasm
├❒ ${prefix}solo
├❒ ${prefix}8ball
├❒ ${prefix}goose
├❒ ${prefix}avatar
├❒ ${prefix}hololewd
├❒ ${prefix}gecg
├❒ ${prefix}holo
├❒ ${prefix}fox_girl
├❒ ${prefix}tits
├❒ ${prefix}eroyuri
├❒ ${prefix}holoyero
├❒ ${prefix}lizard
├❒ ${prefix}keta
├❒ ${prefix}eron
├❒ ${prefix}erok
├❒ ${prefix}kemonomimi
├❒ ${prefix}cum_jpg
├❒ ${prefix}nsfw_avatar
├❒ ${prefix}erofeet
├❒ ${prefix}meow
├❒ ${prefix}wallpaper
├❒ ${prefix}waifu
├❒ ${prefix}trap
├❒ ${prefix}lewd
├❒ ${prefix}pussy_jpg
├❒ ${prefix}futanari
├❒ ${prefix}lewdk
├❒ ${prefix}solog
├❒ ${prefix}smug
├❒ ${prefix}cum
├❒ ${prefix}slap
├❒ ${prefix}les
├❒ ${prefix}erokemo
├❒ ${prefix}bj
├❒ ${prefix}pwankg
├❒ ${prefix}pat
├❒ ${prefix}poke
├❒ ${prefix}feed
├❒ ${prefix}nsfw_neko_gif
├❒ ${prefix}pussy
├❒ ${prefix}feetg
├❒ ${prefix}baka
├❒ ${prefix}hug
├❒ ${prefix}kiss
├❒ ${prefix}tickle
├❒ ${prefix}spank
├❒ ${prefix}kuni
├❒ ${prefix}classic
├❒ ${prefix}boobs
├❒ ${prefix}anal
├❒ ${prefix}ngif
├❒ ${prefix}cuddle
└❒ ${prefix}zettai${petik}
`
}
const asupan = (prefix) => {
	return`┌❑  *ASUPAN MENU* ❑
│
${petik}├❒ ${prefix}rikagusriani 
├❒ ${prefix}ukhty 
├❒ ${prefix}santuy 
├❒ ${prefix}geayubi   
├❒ ${prefix}bocil
├❒ ${prefix}asupan
├❒ ${prefix}chika 
├❒ ${prefix}delvira 
├❒ ${prefix}ayu   
├❒ ${prefix}bunga
├❒ ${prefix}aura
├❒ ${prefix}nisa 
├❒ ${prefix}ziva 
├❒ ${prefix}yana   
├❒ ${prefix}viona
├❒ ${prefix}syania
├❒ ${prefix}riri   
├❒ ${prefix}syifa
├❒ ${prefix}mama_gina
├❒ ${prefix}alcakenya 
└❒ ${prefix}mangayutri${petik}
`
}
const telestiker = (prefix) => {
	return`┌❑  *STICKERS MENU* ❑
│
${petik}├❒ ${prefix}awoawo
├❒ ${prefix}benedict
├❒ ${prefix}chat
├❒ ${prefix}dbfly
├❒ ${prefix}dino_kuning
├❒ ${prefix}doge
├❒ ${prefix}gojosatoru
├❒ ${prefix}hope_boy
├❒ ${prefix}jisoo
├❒ ${prefix}kr_robot
├❒ ${prefix}kucing
├❒ ${prefix}lonte
├❒ ${prefix}manusia_lidi
├❒ ${prefix}menjamet
├❒ ${prefix}meow
├❒ ${prefix}nicholas
├❒ ${prefix}patrick
├❒ ${prefix}popoci
├❒ ${prefix}sponsbob
├❒ ${prefix}kawan_sponsbob
└❒ ${prefix}tyni${petik}
`
}
const image_effect_menu = (prefix) => {
	return`┌❑  *IMAGE EFFECT* ❑
│
${petik}├❒ ${prefix}trigger
├❒ ${prefix}gay
├❒ ${prefix}glass
├❒ ${prefix}passed
├❒ ${prefix}jail
├❒ ${prefix}comrade
├❒ ${prefix}hijau
├❒ ${prefix}biru
├❒ ${prefix}greyscale
├❒ ${prefix}invert
├❒ ${prefix}invert_greyscale
├❒ ${prefix}red
├❒ ${prefix}blurple
├❒ ${prefix}blurple2
├❒ ${prefix}wasted
├❒ ${prefix}pelangi
├❒ ${prefix}wanted
├❒ ${prefix}utatoo
├❒ ${prefix}unsharpen
├❒ ${prefix}thanos
├❒ ${prefix}sniper
├❒ ${prefix}sharpen
├❒ ${prefix}scary
├❒ ${prefix}rip
├❒ ${prefix}rejected
├❒ ${prefix}redple
├❒ ${prefix}posterize
├❒ ${prefix}ps4
├❒ ${prefix}pixelize
├❒ ${prefix}missionpassed
├❒ ${prefix}moustache
├❒ ${prefix}lookwhatkarenhave
├❒ ${prefix}instagram
├❒ ${prefix}glitch
├❒ ${prefix}frame
├❒ ${prefix}fire
├❒ ${prefix}distort
├❒ ${prefix}dictator
├❒ ${prefix}deepfry
├❒ ${prefix}ddungeon
├❒ ${prefix}circle
├❒ ${prefix}challenger
├❒ ${prefix}burn
├❒ ${prefix}brazzers
├❒ ${prefix}beautiful
└❒ ${prefix}sepia${petik}
`
}
const coganmenu = (prefix) => {
	return`┌❑ *GACHA COGAN* ❑
│
├❒ ${petik}${prefix}baekhyung${petik}  
├❒ ${petik}${prefix}dohkyungsoo${petik}  
├❒ ${petik}${prefix}huangzitao${petik}  
├❒ ${petik}${prefix}jhope${petik}  
├❒ ${petik}${prefix}jimin${petik} 
├❒ ${petik}${prefix}jungkook${petik} 
├❒ ${petik}${prefix}kimjondae${petik}  
├❒ ${petik}${prefix}kimjong${petik}  
├❒ ${petik}${prefix}kimjunmyeon${petik}  
├❒ ${petik}${prefix}kimminseok${petik} 
├❒ ${petik}${prefix}kimnanjoon${petik}  
├❒ ${petik}${prefix}kimseok${petik}  
├❒ ${petik}${prefix}kimtaehyung${petik}  
├❒ ${petik}${prefix}luhan${petik}  
├❒ ${petik}${prefix}ohsehun${petik} 
├❒ ${petik}${prefix}parkchanyeol${petik} 
├❒ ${petik}${prefix}suga${petik}  
└❒ ${petik}${prefix}wuyifan${petik}  
`
}

const quotesmenu = (prefix) => {
	return `┌❑ *QUOTES MENU* ❑
│
├❒ ${petik}${prefix}katailham${petik}  
├❒ ${petik}${prefix}dare${petik}   
├❒ ${petik}${prefix}truth${petik}  
├❒ ${petik}${prefix}katabijak_lucu${petik}   
├❒ ${petik}${prefix}katacaklontong${petik}  
└❒ ${petik}${prefix}katadilan${petik}  
`
}
const shopmenu = (prefix) => {
	return `┌❑ *SHOP MENU* ❑
│
├❒ ${petik}${prefix}shop${petik}  
├❒ ${petik}${prefix}price${petik}  
├❒ ${petik}${prefix}pubg${petik}   
├❒ ${petik}${prefix}ml${petik}   
├❒ ${petik}${prefix}ff${petik}   
├❒ ${petik}${prefix}aov${petik}   
├❒ ${petik}${prefix}cod${petik}  
├❒ ${petik}${prefix}sausage${petik}   
├❒ ${petik}${prefix}lol${petik}  
└❒ ${petik}${prefix}valo${petik}  
`
}
const animemenu = (prefix) => {
	return`┌❑ *ANIME MENU* ❑
│
├❒ ${petik}${prefix}anna${petik}
├❒ ${petik}${prefix}asuna_yuki${petik} 
├❒ ${petik}${prefix}ayuzawa${petik} 
├❒ ${petik}${prefix}chitoge${petik} 
├❒ ${petik}${prefix}emilia${petik}
├❒ ${petik}${prefix}erza${petik} 
├❒ ${petik}${prefix}hinata${petik} 
├❒ ${petik}${prefix}inori${petik} 
├❒ ${petik}${prefix}kaga_kouko${petik} 
├❒ ${petik}${prefix}kaori_miyazono${petik} 
├❒ ${petik}${prefix}kotori_minami${petik}
├❒ ${petik}${prefix}mikasa${petik} 
├❒ ${petik}${prefix}mio_akiyama${petik} 
├❒ ${petik}${prefix}mizore_sirayuki${petik} 
├❒ ${petik}${prefix}nakiri_alice${petik} 
├❒ ${petik}${prefix}naruto${petik} 
├❒ ${petik}${prefix}riyas_gremori${petik}
├❒ ${petik}${prefix}sakura${petik} 
├❒ ${petik}${prefix}sasuke${petik} 
├❒ ${petik}${prefix}sento_isuzu${petik} 
├❒ ${petik}${prefix}shana${petik} 
├❒ ${petik}${prefix}shiina${petik} 
├❒ ${petik}${prefix}shinka${petik}
├❒ ${petik}${prefix}winry${petik}
├❒ ${petik}${prefix}yukino${petik} 
├❒ ${petik}${prefix}yuzuki${petik} 
├❒ ${petik}${prefix}akame${petik}
└❒ ${petik}${prefix}mikosiba${petik}
`
}

exports.helpmenu = help
exports.convertmenu = convert
exports.funmenu = fun
exports.downloadmenu = download
exports.makermenu = maker
exports.textpromenu = textpro
exports.photooxymenu = photooxy
exports.othermenu = other
exports.ownermenu = ownermenu
exports.storagemenu = storage
exports.tagmenu = tag
exports.telestiker = telestiker
exports.cecanmenu= cecanmenu
exports.set_stc_cmd =  setStcCmd
exports.upmenu = upmenu
exports.nsfwmenu = nsfw
exports.asupanmenu = asupan
exports.allmenu = allmenu
exports.coganmenu = coganmenu
exports.image_effect = image_effect_menu
exports.quotesmenu = quotesmenu
exports.animemenu = animemenu
exports.shopmenu = shopmenu
