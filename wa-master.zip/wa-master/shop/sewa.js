const pc_sewa = (_minggu, __minggu, ___minggu, _bulan, _permanen, __permanen) => {
return `「 *PRICE LIST* 」
							
⬣ PRICE SEWABOT

⬡ 1 MINGGU = ${_minggu}
⬡ 2 MINGGU = ${__minggu}
⬡ 3 MINGGU = ${___minggu}
⬡ 1 BULAN = ${_bulan}
⬡ PERMANEN = ${_permanen}
⬡ PERMANEN + USER PREM = ${__permanen}


⬣ PRICE JADIBOT

⬡ JADI BOT PERMANEN 25K


⬣ MINAT? PM
⬡ wa.me/62887435047326


NOTE : 
Bot On 24 Jam Karna Di Run Menggunakan Heroku
Reset Data Setiap Jam 02:00 `
	}

exports.pc_sewa = pc_sewa