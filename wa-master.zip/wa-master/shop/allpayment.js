const allpayment = (prefix) => {
return `PAYMENT BY ZEEONE OFC

*🏧 BANK*

1. BRI 
	ㅁ 8881 0887 4350 47326
2. BCA 
	ㅁ 3901 0887 4350 47326
3. BNI 
	ㅁ 881 0887 4350 47326
4. PERMATA
	ㅁ 852 8887 4350 47326
	
*💰 E-MONEY*

1. GOPAY
	ㅁ 0887 4350 47326
2. OVO
	ㅁ 0887 4350 47326
3. DANA
	ㅁ 0887 4350 47326
	
Semuanya atas nama RI****DI

*📲 PULSA*

Tidak tersedia
	
Sebelum melakukan pembayaran ada baiknya anda menghubungi owner terlebih dahulu!
`
	}

exports.allpayment = allpayment
 